<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace User\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;


class IndexController extends AbstractActionController
{
    protected $table;
	public function __construct($table)
	{
		$this->table = $table;
	}
    public function indexAction()
    {
    	return new ViewModel([
            'users' => $this->table->fetchAll()
        ]);
    }
    public function addAction()
    {
        
          error_reporting(0);
          $this->view->retour="add.phtml";
    }

     public function insertAction(){
        error_reporting(0);
         $request = $this->getRequest();

         if ($request->isPost()) {
             $user = new \User\Model\User();
             $user->exchangeArray($_REQUEST);

             if ($user->name!='' && $user->email!='' && $user->address!='') {
                 $this->table->saveUser($user);
                 /*return $this->redirect()->toRoute('user', [
               'controller' => 'index',
               'action' => 'index'
             ]);*/
            $view = new JsonModel();
            //print_r($view);
            //$view->setVariable("Id", $id);
           // return $view;

            //$response->setVariable(204);
            return $view;
            /*return new JsonModel([
            'status' => 'SUCCESS',
            'message'=>'Here is your data',
            'data' => [
                'full_name' => 'John Doe',
                'address' => '51 Middle st.'
            ]
        ]);*/

             /*return [
                'status' => '200',
                'message' => 'Record Inserted Succussfully';
            ];*/
            /*return $view{
                'status' => '200',
                'message' => 'Record Inserted Succussfully';
            };*/
             } 
             else
             {
             
              return $this->redirect()->toRoute('user', [
                   'controller' => 'index',
                   'action' => 'index'
                 ]);
                    
                    

             }

            
         }else{
            $this->view->retour="add.phtml";
         }

    }
     public function editAction()
     {
        $id = (int) $this->params()->fromRoute('id', 0);
   
        if (!$id) {
            return $this->redirect()->toRoute('user', [
           'controller' => 'index',
           'action' => 'add'
         ]);
        }
        try {
            $user = $this->table->getUser($id);
        }
        catch (\Exception $ex) {
            return $this->redirect()->toRoute('user', [
           'controller' => 'index',
           'action' => 'index'
         ]);
        }
         return array(
            'user' => $user,
        );
     }

      public function updateAction(){

       $request = $this->getRequest();
       if ($request->isPost()) {
           $user = new \User\Model\User();
             $user->exchangeArray($_REQUEST);
            $this->table->saveUser($user);
             return $this->redirect()->toRoute('user', [
           'controller' => 'index',
           'action' => 'index',
           'id' => $id
         ]);
       }
    }


     public function listAction()
     {
        return new ViewModel([
            'users' => $this->table->fetchAll()
        ]);

     }
     public function deleteAction()
     {
 
         $id = (int) $this->params()->fromRoute('id',0);
 
         if ($id == 0) {
             exit('invalid id');
         }
 
         try {
             $user = $this->table->getUser($id);
         } catch(\Exception $e) {
             exit('Error with User table');
         }
 
         $request = $this->getRequest();
 
         //if not post request
         if (! $request->isPost()) {
             return new ViewModel([
                 'user' => $user,
                 'id' => $id
             ]);
         }
         //if post request

         $del = $request->getPost('del','No');
         if($del=='Yes')
         {
            $id = (int) $user->getId();
            $this->table->deleteUser($id);

         }
            $this->redirect()->toRoute('user',['action' => 'list']);
     }
}
