<?php
namespace User\Form;

//use Zend\Form\Form;
use Zend\Form\Form;

class UserForm extends Form
{

    public function __construct()
    {
        parent::__construct('user');

        $this->setAttribute('method', 'POST');

        $this->add([
            'name' => 'id',
            'type' => 'hidden'
        ]);



        $this->add([            
            'name' => 'name',
            'type' => 'text',
            'options' => [
                'label' => 'User name'
            ]
        ]);

        $this->add([
            'name' => 'email',
            'type' => 'text',
            'options' => [
                'label' => 'User email'
            ]
        ]);

        $this->add([
            'name' => 'address',
            'type' => 'textarea',
            'options' => [
                'label' => 'User address'
            ]
        ]);
        
         $this->add([
            'name' => 'phone',
            'type' => 'text',
            'options' => [
                'label' => 'Phone number'
            ]
        ]);
         
          $this->add([
            'name' => 'date_of_birth',
            'type' => 'date',
            'options' => [
                'label' => 'Date of birth'
            ]
        ]);

        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
               'value' => 'Save',
               'id'    => 'buttonSave'
            ]
        ]);

    }

}
