<?php

namespace User\Model;

class User
{

public $email;
public $name;
public $id;
public $address;
public $phone;
public $date_of_birth;


    public function exchangeArray(array $data)
    {

        $this->email = $data['email'];
        $this->name= $data['name'];
        $this->id= $data['id'];
        $this->address= $data['address'];   
        $this->phone= $data['phone']; 
        $this->date_of_birth= $data['date_of_birth']; 

    }
    public function getArrayCopy()
    {
        return [
                'email' => $this->email, 
                'name' => $this->name,
                'id' => $this->id,
                'address' => $this->address,
                'phone' => $this->phone,
                'date_of_birth' => $this->date_of_birth 
        ];  

    }
     public function getId()
    {
       return $this->id;
    }
    public function getName()
    {
       return $this->name;
    }

    public function getEmail()
    {
       return $this->email;
    }
    public function getAddress()
    {
       return $this->address;
    }
    public function getPhone()
    {
       return $this->phone;
    }
    public function getDate()
    {
       return $this->date_of_birth;
    }
    
}
